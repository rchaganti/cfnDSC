﻿Enable-NetFirewallRule FPS-ICMP4-ERQ-In

Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any